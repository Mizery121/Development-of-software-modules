def greedy_meetings(meetings, gap=0):
    # сортировка по окончанию
    meetings.sort(key=lambda x: x[1])

    result = []
    last_end = -float('inf')

    for start, end, num in meetings:
        if start >= last_end + gap:
            result.append(num)
            last_end = end

    return result
if __name__ == "__main__":
    data = [
        (1, 3, 1),
        (2, 5, 2),
        (4, 6, 3),
        (6, 8, 4),
        (7, 9, 5),
        (9, 10, 6)
    ]
    pause = 0
    selected = greedy_meetings(data, pause)

    print("заседания (начало-конец-номер):")
    for item in data:
        print(f"{item[2]}: {item[0]}-{item[1]}")

    print(f"\nПерерыв: {pause}")
    print(f"Выбраны: {selected}")
    print(f"Всего: {len(selected)}")