# ============================
# Класс House (Задание Часть 2)
# ============================
class House:
    def __init__(self, area, price):
        """
        Инициализация дома

        Args:
            area: площадь дома
            price: начальная цена дома
        """
        self.__area = area  # Приватное свойство
        self.__price = price  # Приватное свойство

    def final_price(self, discount=0):
        """
        Расчет конечной цены с учетом скидки

        Args:
            discount: размер скидки в процентах (от 0 до 100)

        Returns:
            Цена с учетом скидки
        """
        return self.__price * (1 - discount / 100)

    def get_info(self):
        """Возвращает информацию о доме"""
        return f"Дом площадью {self.__area} м², начальная цена: {self.__price}"

    def get_price(self):
        """Геттер для начальной цены"""
        return self.__price

    def get_area(self):
        """Геттер для площади"""
        return self.__area


# ============================
# Класс SmallHouse (Задание Часть 3)
# ============================
class SmallHouse(House):
    def __init__(self, price):
        """
        Инициализация маленького дома

        Args:
            price: начальная цена дома
        """
        # Вызываем конструктор родительского класса с фиксированной площадью 40 м²
        super().__init__(40, price)

    def get_info(self):
        """Переопределяем метод для уточнения типа дома"""
        return f"Маленький дом площадью {self.get_area()} м², начальная цена: {self.get_price()}"


# ============================
# Класс Human (Задание Часть 1)
# ============================
class Human:
    # Статические поля
    default_name = "Иван"
    default_age = 30

    def __init__(self, name=default_name, age=default_age):
        """
        Инициализация человека

        Args:
            name: имя человека (по умолчанию из статического поля)
            age: возраст человека (по умолчанию из статического поля)
        """
        # Публичные свойства
        self.name = name
        self.age = age

        # Приватные свойства
        self.__money = 0
        self.__house = None

    def info(self):
        """Вывод информации о человеке"""
        print(f"Имя: {self.name}")
        print(f"Возраст: {self.age}")
        print(f"Деньги: {self.__money}")
        if self.__house:
            print(f"Дом: {self.__house.get_info()}")
        else:
            print("Дом: отсутствует")

    @staticmethod
    def default_info():
        """Вывод статических полей класса"""
        print(f"default_name: {Human.default_name}")
        print(f"default_age: {Human.default_age}")

    def earn_money(self, amount):
        """
        Увеличение количества денег

        Args:
            amount: сумма для добавления
        """
        if amount > 0:
            self.__money += amount
            print(f"Заработано {amount}. Теперь денег: {self.__money}")

    def __make_deal(self, house, price):
        """
        Приватный метод для совершения покупки дома

        Args:
            house: объект дома
            price: цена покупки
        """
        self.__money -= price
        self.__house = house
        print(f"Куплен дом за {price:.2f}. Осталось денег: {self.__money}")

    def buy_house(self, house, discount=0):
        """
        Покупка дома со скидкой

        Args:
            house: объект дома класса House или SmallHouse
            discount: размер скидки в процентах (от 0 до 100)

        Returns:
            True если покупка успешна, False если нет
        """
        # Получаем конечную цену с учетом скидки
        final_price = house.final_price(discount)

        print(f"Попытка покупки: {house.get_info()}")
        print(f"Скидка: {discount}%")
        print(f"Итоговая цена: {final_price:.2f}")
        print(f"Денег у {self.name}: {self.__money}")

        # Проверяем, достаточно ли денег
        if self.__money >= final_price:
            self.__make_deal(house, final_price)
            return True
        else:
            needed = final_price - self.__money
            print(f"Недостаточно денег! Нужно еще: {needed:.2f}")
            return False


# ============================
# Выполнение задания Часть 4
# ============================
if __name__ == "__main__":
    print("=" * 60)
    print("ПОЛНАЯ ПРОГРАММА: ОБЪЕДИНЕНИЕ ВСЕХ ЧАСТЕЙ ЗАДАНИЯ")
    print("=" * 60)

    # Шаг 1: Вызвать справочный метод default_info() для класса Human
    print("\nШАГ 1: Вызываем справочный метод default_info() для класса Human")
    print("-" * 40)
    Human.default_info()

    # Шаг 2: Создать объект класса Human
    print("\nШАГ 2: Создаем объект класса Human")
    print("-" * 40)
    person = Human()
    print(f"Создан объект класса Human:")
    print(f"  Имя: {person.name} (использовано значение по умолчанию)")
    print(f"  Возраст: {person.age} (использовано значение по умолчанию)")

    # Шаг 3: Вывести справочную информацию о созданном объекте
    print("\nШАГ 3: Выводим справочную информацию о созданном объекте (метод info())")
    print("-" * 40)
    person.info()

    # Шаг 4: Создать объект класса SmallHouse
    print("\nШАГ 4: Создаем объект класса SmallHouse")
    print("-" * 40)
    small_house = SmallHouse(15000)
    print(f"Создан объект класса SmallHouse:")
    print(f"  {small_house.get_info()}")
    print(f"  Проверка: площадь = {small_house.get_area()} м² (должно быть 40 м²)")
    print(f"  Проверка: начальная цена = {small_house.get_price()}")

    # Шаг 5: Попробовать купить созданный дом
    print("\nШАГ 5: Пытаемся купить созданный дом")
    print("-" * 40)
    print("Ожидаем предупреждение о недостатке денег...")
    print()
    success1 = person.buy_house(small_house)
    print(f"\nРезультат покупки: {'Успешно' if success1 else 'Неудачно'}")

    # Шаг 6: Поправить финансовое положение
    print("\nШАГ 6: Поправляем финансовое положение - вызываем метод earn_money()")
    print("-" * 40)
    person.earn_money(20000)

    # Шаг 7: Снова попробовать купить дом
    print("\nШАГ 7: Снова пытаемся купить дом")
    print("-" * 40)
    print("Ожидаем успешную покупку...")
    print()
    success2 = person.buy_house(small_house)
    print(f"\nРезультат покупки: {'Успешно' if success2 else 'Неудачно'}")

    # Шаг 8: Посмотреть, как изменилось состояние объекта
    print("\nШАГ 8: Смотрим, как изменилось состояние объекта класса Human")
    print("-" * 40)
    person.info()

    # Дополнительная информация для проверки
    print("\n" + "=" * 60)
    print("ДОПОЛНИТЕЛЬНАЯ ИНФОРМАЦИЯ")
    print("=" * 60)

    # Проверка наследования
    print("\nПроверка наследования классов:")
    print(f"  small_house является экземпляром SmallHouse: {isinstance(small_house, SmallHouse)}")
    print(f"  small_house является экземпляром House: {isinstance(small_house, House)}")
    print(f"  small_house имеет метод final_price: {hasattr(small_house, 'final_price')}")

    # Проверка скидки
    print("\nПроверка метода final_price с разными скидками:")
    for discount in [0, 10, 20, 50]:
        price = small_house.final_price(discount)
        print(f"  Со скидкой {discount}%: {price:.2f}")

    print("\n" + "=" * 60)
    print("ПРОГРАММА УСПЕШНО ЗАВЕРШЕНА")
    print("=" * 60)