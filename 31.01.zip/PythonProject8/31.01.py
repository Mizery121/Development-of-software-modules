class House:
    def __init__(self, area, price):
        """
        Инициализация дома

        Args:
            area: площадь дома
            price: начальная цена дома
        """
        self.__area = area  # Приватное свойство
        self.__price = price  # Приватное свойство

    def final_price(self, discount=0):
        """
        Расчет конечной цены с учетом скидки

        Args:
            discount: размер скидки в процентах (от 0 до 100)

        Returns:
            Цена с учетом скидки
        """
        return self.__price * (1 - discount / 100)

    def get_info(self):
        """Возвращает информацию о доме"""
        return f"Дом площадью {self.__area} м², начальная цена: {self.__price}"

    def get_price(self):
        """Геттер для начальной цены"""
        return self.__price

    def get_area(self):
        """Геттер для площади"""
        return self.__area


class Human:
    # Статические поля
    default_name = "Иван"
    default_age = 30

    def __init__(self, name=default_name, age=default_age):
        """
        Инициализация человека

        Args:
            name: имя человека (по умолчанию из статического поля)
            age: возраст человека (по умолчанию из статического поля)
        """
        # Публичные свойства
        self.name = name
        self.age = age

        # Приватные свойства
        self.__money = 0
        self.__house = None

    def info(self):
        """Вывод информации о человеке"""
        print(f"Имя: {self.name}")
        print(f"Возраст: {self.age}")
        print(f"Деньги: {self.__money}")
        if self.__house:
            print(f"Дом: {self.__house.get_info()}")
        else:
            print("Дом: отсутствует")
        print("-" * 30)

    @staticmethod
    def default_info():
        """Вывод статических полей класса"""
        print(f"default_name: {Human.default_name}")
        print(f"default_age: {Human.default_age}")

    def earn_money(self, amount):
        """
        Увеличение количества денег

        Args:
            amount: сумма для добавления
        """
        if amount > 0:
            self.__money += amount
            print(f"{self.name} заработал {amount}. Теперь денег: {self.__money}")
        else:
            print("Сумма должна быть положительной!")

    def __make_deal(self, house, price):
        """
        Приватный метод для совершения покупки дома

        Args:
            house: объект дома
            price: цена покупки
        """
        self.__money -= price
        self.__house = house
        print(f"{self.name} купил дом за {price:.2f}. Осталось денег: {self.__money}")

    def buy_house(self, house, discount=0):
        """
        Покупка дома со скидкой

        Args:
            house: объект дома класса House
            discount: размер скидки в процентах (от 0 до 100)

        Returns:
            True если покупка успешна, False если нет
        """
        # Получаем конечную цену с учетом скидки
        final_price = house.final_price(discount)

        print(f"Попытка покупки дома: {house.get_info()}")
        print(f"Скидка: {discount}%")
        print(f"Итоговая цена: {final_price:.2f}")
        print(f"Денег у {self.name}: {self.__money}")

        # Проверяем, достаточно ли денег
        if self.__money >= final_price:
            self.__make_deal(house, final_price)
            return True
        else:
            needed = final_price - self.__money
            print(f"Недостаточно денег! Нужно еще: {needed:.2f}")
            return False


# Демонстрация работы программы
if __name__ == "__main__":
    print("=" * 50)
    print("ДЕМОНСТРАЦИЯ РАБОТЫ ПРОГРАММЫ")
    print("=" * 50)

    # 1. Выводим статическую информацию
    print("1. Статическая информация о классе Human:")
    Human.default_info()
    print()

    # 2. Создаем людей
    print("2. Создаем людей:")
    person1 = Human()  # С параметрами по умолчанию
    person2 = Human("Мария", 28)
    person3 = Human("Алексей", 35)

    person1.info()
    person2.info()
    person3.info()

    # 3. Создаем дома
    print("3. Создаем дома:")
    house1 = House(50, 30000)  # Площадь 50 м², цена 30000
    house2 = House(80, 50000)  # Площадь 80 м², цена 50000
    house3 = House(120, 80000)  # Площадь 120 м², цена 80000

    print(f"Дом 1: {house1.get_info()}")
    print(f"Дом 2: {house2.get_info()}")
    print(f"Дом 3: {house3.get_info()}")
    print()

    # 4. Люди зарабатывают деньги
    print("4. Люди зарабатывают деньги:")
    person1.earn_money(40000)
    person2.earn_money(60000)
    person3.earn_money(100000)
    print()

    # 5. Покупка домов
    print("5. Попытка покупки домов:")

    print("\nАлексей пытается купить дорогой дом со скидкой 20%:")
    person3.buy_house(house3, 20)

    print("\nМария пытается купить средний дом:")
    person2.buy_house(house2)

    print("\nИван пытается купить маленький дом со скидкой 10%:")
    person1.buy_house(house1, 10)
    print()

    # 6. Еще зарабатываем и пробуем купить
    print("6. Иван зарабатывает еще денег и пытается купить дом:")
    person1.earn_money(20000)
    person1.buy_house(house1, 10)
    print()

    # 7. Финальная информация о людях
    print("7. Финальная информация о людях:")
    person1.info()
    person2.info()
    person3.info()

    # 8. Проверяем цену дома с разными скидками
    print("8. Проверка метода final_price() класса House:")
    test_house = House(100, 100000)
    print(f"Тестовый дом: {test_house.get_info()}")

    discounts = [0, 10, 20, 50]
    for discount in discounts:
        price = test_house.final_price(discount)
        print(f"  Со скидкой {discount}%: {price:.2f}")

    print("\n" + "=" * 50)
    print("ПРОГРАММА ЗАВЕРШЕНА")
    print("=" * 50)